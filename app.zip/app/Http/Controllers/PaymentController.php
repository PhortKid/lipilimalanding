<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function access_token()
    {

        return 'access token';
    }

    public function register_ipn()
    {

        return 'register ipn';
    }

    public function registered_ipn()
    {

        return 'registered ipn';
    }

    public function submit_request()
    {

        return 'submit request';
    }


}
